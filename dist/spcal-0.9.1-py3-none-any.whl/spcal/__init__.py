# src/spcal/__init__.py
from .spcal import sp_core  # noqa: F401
__all__ = ["sp_core"]